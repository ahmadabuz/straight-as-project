/* ═══════════════════════════════════════════════
   SCHOLARLY — Frontend Application
   Connects to: /api/universities, /api/universities/:id/materials
═══════════════════════════════════════════════ */

'use strict';

/* ─── CONFIG ─────────────────────────────────── */
const API_BASE = '';   // same origin; adjust if backend runs on different port
const COURSES_PER_PAGE = 9;

/* ─── MOCK DATA (mirrors real API shape) ─────── */
// In production these are replaced by real API calls to /api/universities and materials
const MOCK_COURSES = [
  { id:1,  title:'Introduction to Machine Learning',      description:'Dive into supervised and unsupervised learning, neural networks, and real-world ML pipelines using Python and scikit-learn.',     category:'Computer Science', instructor:'Dr. Sara Khalil',   university:'Jordan University of Science',  rating:4.9, students:3241, emoji:'🤖', thumb_bg:'#1A1F3A' },
  { id:2,  title:'Calculus III: Multivariable Methods',   description:'Explore vector calculus, partial derivatives, multiple integrals, and Stokes\' theorem with geometric intuition.',               category:'Mathematics',      instructor:'Prof. Omar Nasser', university:'University of Jordan',          rating:4.7, students:1802, emoji:'∫',  thumb_bg:'#2A1A3A' },
  { id:3,  title:'Digital Circuit Design',                description:'From logic gates to FPGAs: learn combinational and sequential circuits, timing analysis, and HDL programming.',                   category:'Engineering',      instructor:'Dr. Lina Haddad',  university:'Princess Sumaya University',    rating:4.8, students:2156, emoji:'⚡', thumb_bg:'#1A2A1A' },
  { id:4,  title:'Strategic Management & Innovation',     description:'Frameworks for competitive strategy, innovation management, and navigating organizational change in global markets.',             category:'Business',         instructor:'Dr. Rami Saleh',   university:'Arab Open University',          rating:4.6, students:2988, emoji:'📊', thumb_bg:'#2A1A1A' },
  { id:5,  title:'UI/UX Design Fundamentals',            description:'Master the full design process: user research, wireframing, prototyping in Figma, and usability testing.',                         category:'Design',           instructor:'Nadia Barakat',    university:'Applied Science University',    rating:4.9, students:4102, emoji:'🎨', thumb_bg:'#1A2A2A' },
  { id:6,  title:'Quantum Mechanics I',                  description:'Wave functions, the Schrödinger equation, quantum tunneling, and the measurement problem — rigorously derived from first principles.',category:'Science',         instructor:'Prof. Fadi Murad', university:'University of Jordan',          rating:4.8, students:987,  emoji:'⚛',  thumb_bg:'#2A2A1A' },
  { id:7,  title:'Data Structures & Algorithms',         description:'Master arrays, trees, graphs, dynamic programming, and complexity analysis. Essential preparation for technical interviews.',       category:'Computer Science', instructor:'Dr. Maya Issa',    university:'German Jordanian University',   rating:4.8, students:5630, emoji:'🌳', thumb_bg:'#1A1F3A' },
  { id:8,  title:'Ordinary Differential Equations',      description:'Analytical and numerical methods for ODEs: phase portraits, stability analysis, Laplace transforms, and series solutions.',        category:'Mathematics',      instructor:'Dr. Ahmad Zaid',   university:'Hashemite University',          rating:4.5, students:1243, emoji:'〒',  thumb_bg:'#2A1A3A' },
  { id:9,  title:'Structural Engineering Principles',    description:'Load analysis, beam theory, truss design, and introduction to finite element methods for civil and structural engineers.',          category:'Engineering',      instructor:'Dr. Khaled Awad',  university:'Mutah University',              rating:4.7, students:1580, emoji:'🏗',  thumb_bg:'#1A2A1A' },
  { id:10, title:'Entrepreneurship & Startup Finance',   description:'From idea to IPO: business model canvas, cap tables, fundraising, term sheets, and financial modeling for founders.',              category:'Business',         instructor:'Samer Tuqan',      university:'Arab Open University',          rating:4.6, students:2210, emoji:'🚀', thumb_bg:'#2A1A1A' },
  { id:11, title:'Advanced Typography & Layout',         description:'Grid systems, typographic hierarchy, editorial design, and the craft of building beautiful, readable visual systems.',             category:'Design',           instructor:'Rana Khoury',      university:'Applied Science University',    rating:4.7, students:1740, emoji:'✍',  thumb_bg:'#1A2A2A' },
  { id:12, title:'Organic Chemistry I',                  description:'Molecular bonding, stereochemistry, reaction mechanisms, and synthesis strategies. Lab safety and spectroscopic analysis included.',category:'Science',         instructor:'Dr. Dina Abboud',  university:'Jordan University of Science',  rating:4.6, students:1891, emoji:'🧪', thumb_bg:'#2A2A1A' },
  { id:13, title:'Computer Networks & Security',         description:'OSI model, TCP/IP stack, cryptographic protocols, network attacks, and defenses. Hands-on lab using Wireshark.',                  category:'Computer Science', instructor:'Dr. Basem Hani',   university:'Philadelphia University',       rating:4.7, students:2830, emoji:'🔐', thumb_bg:'#1A1F3A' },
  { id:14, title:'Linear Algebra for Engineers',         description:'Vectors, matrices, eigenvalues, SVD, and applications to machine learning, graphics, and signal processing.',                      category:'Mathematics',      instructor:'Prof. Reem Kawar', university:'German Jordanian University',   rating:4.8, students:3340, emoji:'🔢', thumb_bg:'#2A1A3A' },
  { id:15, title:'Renewable Energy Systems',             description:'Solar, wind, and hydropower technologies, grid integration, energy storage, and policy frameworks for sustainable energy.',         category:'Engineering',      instructor:'Dr. Wisam Najjar', university:'Hashemite University',          rating:4.6, students:1432, emoji:'☀',  thumb_bg:'#1A2A1A' },
  { id:16, title:'Principles of Marketing',              description:'Consumer behaviour, market segmentation, brand strategy, digital marketing analytics, and campaign planning for modern businesses.', category:'Business',        instructor:'Sana Qasem',       university:'Yarmouk University',             rating:4.5, students:2760, emoji:'📣', thumb_bg:'#2A1A1A' },
  { id:17, title:'Motion Graphics & Animation',          description:'Keyframing, easing, character rigging, and storytelling through motion. Projects in After Effects and Blender.',                  category:'Design',           instructor:'Tarek Barakat',    university:'Applied Science University',    rating:4.8, students:2190, emoji:'🎬', thumb_bg:'#1A2A2A' },
  { id:18, title:'Molecular Biology & Genetics',         description:'DNA replication, transcription, translation, CRISPR, PCR, and the molecular basis of genetic diseases and biotechnology.',         category:'Science',          instructor:'Dr. Rula Hamdan',  university:'Jordan University of Science',  rating:4.9, students:2041, emoji:'🧬', thumb_bg:'#2A2A1A' },
];

const MOCK_UNIVERSITIES = [
  { id:1, name:'University of Jordan',          country:'Jordan', materials:38, founded:1962, emoji:'🏛', bg:'#1A1F3A' },
  { id:2, name:'Jordan University of Science',  country:'Jordan', materials:51, founded:1979, emoji:'⚗',  bg:'#1A2A1A' },
  { id:3, name:'German Jordanian University',   country:'Jordan', materials:29, founded:2005, emoji:'🎓', bg:'#2A1A3A' },
  { id:4, name:'Hashemite University',          country:'Jordan', materials:22, founded:1995, emoji:'📚', bg:'#2A2A1A' },
  { id:5, name:'Arab Open University',          country:'Jordan', materials:44, founded:2002, emoji:'🌐', bg:'#1A2A2A' },
  { id:6, name:'Applied Science University',    country:'Jordan', materials:33, founded:1989, emoji:'🔬', bg:'#2A1A1A' },
  { id:7, name:'Princess Sumaya University',    country:'Jordan', materials:18, founded:1991, emoji:'💻', bg:'#1A1F3A' },
  { id:8, name:'Philadelphia University',       country:'Jordan', materials:25, founded:1989, emoji:'⚡', bg:'#2A1F1A' },
  { id:9, name:'Yarmouk University',            country:'Jordan', materials:31, founded:1976, emoji:'📖', bg:'#1A2A3A' },
  { id:10,name:'Mutah University',              country:'Jordan', materials:19, founded:1981, emoji:'🏗', bg:'#2A1A2A' },
];

/* ─── STATE ──────────────────────────────────── */
const state = {
  currentPage: 'home',
  courses:    [...MOCK_COURSES],
  filtered:   [...MOCK_COURSES],
  searchQuery:'',
  activeCategory: 'all',
  sortBy:     'newest',
  viewMode:   'grid',
  currentPageNum: 1,
};

/* ─── THEME ──────────────────────────────────── */
const html = document.documentElement;
const themeToggle = document.getElementById('themeToggle');

function initTheme() {
  const saved = localStorage.getItem('scholarly-theme') || 'dark';
  html.setAttribute('data-theme', saved);
}

themeToggle.addEventListener('click', () => {
  const current = html.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  localStorage.setItem('scholarly-theme', next);
});

/* ─── NAVIGATION ─────────────────────────────── */
const navbar   = document.getElementById('navbar');
const navLinks = document.getElementById('navLinks');
const hamburger = document.getElementById('hamburger');

window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 20);
});

hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('open');
  navLinks.classList.toggle('open');
});

function navigateTo(pageId) {
  if (!pageId || pageId === state.currentPage) return;

  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l => {
    l.classList.toggle('active', l.dataset.page === pageId);
  });

  const target = document.getElementById(`page-${pageId}`);
  if (!target) return;

  target.classList.add('active');
  state.currentPage = pageId;

  window.scrollTo({ top: 0, behavior: 'smooth' });
  navLinks.classList.remove('open');
  hamburger.classList.remove('open');

  // Page-specific init
  if (pageId === 'courses')      renderCoursesPage();
  if (pageId === 'universities') renderUniversitiesPage();
  if (pageId === 'home')         initHeroAnimations();
}

// Global click delegation for [data-page] links
document.addEventListener('click', e => {
  const target = e.target.closest('[data-page]');
  if (target) {
    e.preventDefault();
    navigateTo(target.dataset.page);
  }
});

/* ─── COUNTER ANIMATION ──────────────────────── */
function animateCounter(el, target, suffix) {
  const duration = 1600;
  const start = performance.now();
  const update = now => {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(eased * target);
    if (progress < 1) requestAnimationFrame(update);
    else el.textContent = target;
  };
  requestAnimationFrame(update);
}

function initHeroAnimations() {
  const counters = document.querySelectorAll('.stat-num');
  counters.forEach(el => {
    animateCounter(el, parseInt(el.dataset.count, 10));
  });
}

/* ─── BADGE CLASS ────────────────────────────── */
const CAT_BADGE = {
  'Computer Science': 'badge-cs',
  'Engineering':      'badge-eng',
  'Mathematics':      'badge-math',
  'Business':         'badge-biz',
  'Design':           'badge-design',
  'Science':          'badge-sci',
};

function badgeClass(cat) {
  return CAT_BADGE[cat] || 'badge-other';
}

function stars(rating) {
  const full  = Math.floor(rating);
  const half  = rating % 1 >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(empty);
}

function initials(name) {
  return name.split(' ').filter(w => /^[A-Z]/.test(w)).slice(0, 2).map(w => w[0]).join('');
}

/* ─── COURSE CARD HTML ───────────────────────── */
function courseCardHTML(c) {
  const bg = c.thumb_bg || '#1A1F3A';
  return `
    <article class="course-card fade-in">
      <div class="course-thumb" style="background:${bg}">
        <span style="user-select:none">${c.emoji || '📖'}</span>
        <span class="course-badge ${badgeClass(c.category)}">${c.category}</span>
      </div>
      <div class="course-body">
        <div class="course-cat">${c.category}</div>
        <h3 class="course-title">${c.title}</h3>
        <p class="course-desc">${c.description}</p>
        <div class="course-meta">
          <div class="course-instructor">
            <div class="instructor-avatar">${initials(c.instructor)}</div>
            <span>${c.instructor}</span>
          </div>
          <div class="course-rating">
            <span class="stars">${stars(c.rating)}</span>
            <span>${c.rating.toFixed(1)}</span>
          </div>
        </div>
        <div class="course-footer">
          <span class="course-students">👥 ${c.students.toLocaleString()} students</span>
          <button class="btn-enroll">Enroll →</button>
        </div>
      </div>
    </article>
  `;
}

/* ─── COURSES PAGE ───────────────────────────── */
function renderCoursesPage() {
  applyFilters();
}

function applyFilters() {
  const q   = state.searchQuery.toLowerCase().trim();
  const cat = state.activeCategory;

  state.filtered = state.courses.filter(c => {
    const matchCat   = cat === 'all' || c.category === cat;
    const matchQuery = !q ||
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.instructor.toLowerCase().includes(q) ||
      c.university.toLowerCase().includes(q);
    return matchCat && matchQuery;
  });

  // Sort
  if (state.sortBy === 'popular') state.filtered.sort((a,b) => b.students - a.students);
  else if (state.sortBy === 'rating') state.filtered.sort((a,b) => b.rating - a.rating);
  else state.filtered.sort((a,b) => b.id - a.id);

  state.currentPageNum = 1;
  renderCourseGrid();
  renderPagination();
  updateResultsMeta();
}

function renderCourseGrid() {
  const grid = document.getElementById('coursesGrid');
  if (!grid) return;

  const start = (state.currentPageNum - 1) * COURSES_PER_PAGE;
  const end   = start + COURSES_PER_PAGE;
  const page  = state.filtered.slice(start, end);

  if (page.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <h3>No courses found</h3>
        <p>Try adjusting your search or filters</p>
      </div>`;
    return;
  }

  grid.innerHTML = page.map(courseCardHTML).join('');
  grid.className = `courses-grid${state.viewMode === 'list' ? ' list-view' : ''}`;
}

function renderPagination() {
  const total = Math.ceil(state.filtered.length / COURSES_PER_PAGE);
  const cur   = state.currentPageNum;
  const pg    = document.getElementById('pagination');
  if (!pg) return;

  if (total <= 1) { pg.innerHTML = ''; return; }

  let html = '';
  if (cur > 1) html += `<button class="page-btn" data-p="${cur-1}">‹</button>`;

  for (let i = 1; i <= total; i++) {
    if (i === 1 || i === total || Math.abs(i - cur) <= 1) {
      html += `<button class="page-btn${i === cur ? ' active' : ''}" data-p="${i}">${i}</button>`;
    } else if (Math.abs(i - cur) === 2) {
      html += `<span style="color:var(--c-muted);padding:0 4px">…</span>`;
    }
  }

  if (cur < total) html += `<button class="page-btn" data-p="${cur+1}">›</button>`;
  pg.innerHTML = html;
}

function updateResultsMeta() {
  const el = document.getElementById('resultsCount');
  if (!el) return;
  const total = state.filtered.length;
  el.textContent = total === 0
    ? 'No courses found'
    : `Showing ${total} course${total !== 1 ? 's' : ''}`;
}

/* ─── SEARCH & FILTERS ───────────────────────── */
let searchTimeout;
const searchInput = document.getElementById('searchInput');
const searchClear = document.getElementById('searchClear');

if (searchInput) {
  searchInput.addEventListener('input', e => {
    state.searchQuery = e.target.value;
    searchClear.classList.toggle('visible', state.searchQuery.length > 0);
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(applyFilters, 250);
  });
}

if (searchClear) {
  searchClear.addEventListener('click', () => {
    searchInput.value = '';
    state.searchQuery = '';
    searchClear.classList.remove('visible');
    applyFilters();
    searchInput.focus();
  });
}

document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.activeCategory = btn.dataset.cat;
    applyFilters();
  });
});

const sortSelect = document.getElementById('sortSelect');
if (sortSelect) {
  sortSelect.addEventListener('change', e => {
    state.sortBy = e.target.value;
    applyFilters();
  });
}

document.querySelectorAll('.view-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.viewMode = btn.dataset.view;
    renderCourseGrid();
  });
});

// Pagination delegation
document.getElementById('pagination')?.addEventListener('click', e => {
  const btn = e.target.closest('.page-btn');
  if (btn) {
    state.currentPageNum = parseInt(btn.dataset.p, 10);
    renderCourseGrid();
    renderPagination();
    updateResultsMeta();
    window.scrollTo({ top: document.querySelector('.page-hero')?.offsetTop || 0, behavior: 'smooth' });
  }
});

/* ─── HOME PREVIEW COURSES ───────────────────── */
function renderPreviewCourses() {
  const grid = document.getElementById('previewGrid');
  if (!grid) return;
  const top3 = [...MOCK_COURSES]
    .sort((a,b) => b.students - a.students)
    .slice(0, 3);
  grid.innerHTML = top3.map(courseCardHTML).join('');
}

/* ─── UNIVERSITIES PAGE ──────────────────────── */
async function renderUniversitiesPage() {
  const grid = document.getElementById('uniGrid');
  if (!grid) return;

  // Try real API first; fall back to mock data
  let unis = MOCK_UNIVERSITIES;
  try {
    const res = await fetch(`${API_BASE}/api/universities`);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        unis = data.map((u, i) => ({
          ...u,
          emoji: MOCK_UNIVERSITIES[i % MOCK_UNIVERSITIES.length].emoji,
          bg:    MOCK_UNIVERSITIES[i % MOCK_UNIVERSITIES.length].bg,
          country: 'Jordan',
          founded: '–',
          materials: u.material_count || 0,
        }));
      }
    }
  } catch (_) { /* offline / different port — use mock */ }

  grid.innerHTML = unis.map(u => `
    <div class="uni-card fade-in">
      <div class="uni-emblem" style="background:${u.bg}; font-size:26px">${u.emoji}</div>
      <h3>${u.name}</h3>
      <p>${u.country}${u.founded !== '–' ? ` · Est. ${u.founded}` : ''}</p>
      <div class="uni-meta">
        <span><strong>${u.materials}</strong> materials</span>
      </div>
    </div>
  `).join('');
}

/* ─── PAGE-LEVEL DELEGATION (pagination) ────── */
document.addEventListener('click', e => {
  const btn = e.target.closest('#pagination .page-btn');
  if (btn) {
    state.currentPageNum = parseInt(btn.dataset.p, 10);
    renderCourseGrid();
    renderPagination();
    updateResultsMeta();
  }
});

/* ─── INTERSECTION OBSERVER (lazy fade-in) ──── */
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

function observeSections() {
  document.querySelectorAll('.feature-card, .testi-card, .value-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    observer.observe(el);
  });
}

/* ─── BOOT ───────────────────────────────────── */
function boot() {
  initTheme();
  renderPreviewCourses();
  initHeroAnimations();
  observeSections();

  // Handle hash navigation
  const hash = window.location.hash.replace('#', '');
  if (hash && ['courses','universities','about'].includes(hash)) {
    navigateTo(hash);
  }
}

document.addEventListener('DOMContentLoaded', boot);
