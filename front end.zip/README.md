# Scholarly — Online Learning Platform

A modern, responsive learning platform built with Express.js + Vanilla JS.

## Project Structure

```
/
├── server.js              ← Main Express entry point
├── db.js                  ← SQLite database setup (yours)
├── routes/
│   └── universities.js    ← API routes (yours, unchanged)
└── public/                ← Static frontend (new)
    ├── index.html         ← Single-page app shell
    ├── styles.css         ← Full design system
    └── app.js             ← SPA router + API integration
```

## Setup & Run

```bash
# 1. Install dependencies (if not already)
npm install express

# 2. Start the server
node server.js

# 3. Open in your browser
open http://localhost:3000
```

## Pages

| Route   | Description                                      |
|---------|--------------------------------------------------|
| `/`     | Homepage — hero, features, course preview, CTA   |
| `#courses`      | Courses grid with search, filter, pagination |
| `#universities` | Partner universities (live from /api/universities) |
| `#about`        | About page                                   |

## API Integration

The frontend auto-connects to your existing backend:

| Endpoint                        | Used for                       |
|---------------------------------|--------------------------------|
| `GET /api/universities`         | Universities page listing       |
| `GET /api/universities/:id/materials` | (ready for course detail page) |

When the API is unavailable (e.g. running index.html standalone), the frontend gracefully falls back to realistic mock data.

## Features

- 🌗 **Dark / Light mode** — persisted in localStorage  
- 📱 **Fully responsive** — mobile, tablet, desktop  
- 🔍 **Live search** — debounced, searches title/description/instructor  
- 🗂 **Category filters** — CS, Engineering, Maths, Business, Design, Science  
- 📄 **Pagination** — 9 courses per page with smart ellipsis  
- 🎨 **Grid / List view** toggle  
- ⚡ **Skeleton loaders** — shown before content loads  
- ✨ **Scroll animations** — intersection observer fade-ins  
- 🔢 **Animated counters** — hero statistics

## Customisation

**Colors** — edit CSS variables at the top of `styles.css`:
```css
--c-accent:  #00E5B4;   /* primary brand colour */
--c-gold:    #FFB84D;   /* ratings, highlights  */
```

**Courses** — replace `MOCK_COURSES` in `app.js` with a real API call to your materials endpoint once your materials routes are ready.

**Fonts** — loaded from Google Fonts: `Syne` (headings) + `Manrope` (body). Change the `<link>` in `index.html` to swap.
