/**
 * Scholarly — Express Server
 * Serves static frontend + mounts API routes
 * Run: node server.js
 */

const express = require('express');
const path    = require('path');
const app     = express();

/* ── Middleware ──────────────────────────────── */
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

/* ── Static Frontend ─────────────────────────── */
// Serve everything in ./public as static files
app.use(express.static(path.join(__dirname, 'public')));

/* ── API Routes ──────────────────────────────── */
// Mount your existing route files under /api/*
try {
  const universitiesRouter = require('./routes/universities');
  app.use('/api/universities', universitiesRouter);
} catch (e) {
  console.warn('[warn] Could not load universities router:', e.message);
}

// Add more route mounts here as you create them:
// app.use('/api/materials',   require('./routes/materials'));
// app.use('/api/categories',  require('./routes/categories'));
// app.use('/api/users',       require('./routes/users'));

/* ── SPA Catch-all ───────────────────────────── */
// Any unmatched GET request returns the frontend (supports direct URL navigation)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

/* ── Start ───────────────────────────────────── */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n✅  Scholarly is running at http://localhost:${PORT}\n`);
});

module.exports = app;
